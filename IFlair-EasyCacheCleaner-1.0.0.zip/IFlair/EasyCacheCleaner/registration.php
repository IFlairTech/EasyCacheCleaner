<?php
/**
 * Copyright © 2016 iFlair Web Technologies. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'IFlair_EasyCacheCleaner',
    __DIR__
);
